TOT AIXO S'HAURA DE COPIAR AL BOWER/DIST
totes les carpetes indispensables.
index2.html es l'inici bo (un cop loggejat)
login.html evidentemnt es el login
index.html es el que venia per defecte
inici.html es una prova
index.php conte proves denviament de dades
